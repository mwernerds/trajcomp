## ---- echo=FALSE---------------------------------------------------------
library(trajcomp)
data(prague)

#get trajectory
prague$tid = getTrajectoryIDs(prague); # Add ID column
# and split on it
psplit = split (prague, f = prague$tid);
traj <- psplit[[1]];

#trajectory plot
plot(traj$x, traj$y, col="orange",
  main="Trajectory",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x, traj$y, col="black")

#curve plot
curve <- persistence_curve(as.matrix(traj))
plot(curve,  col="orange",
  main="Curve from Trajectory",
  xlab="Index",
  ylab="Curvature (Degrees)")
lines(curve, col="black")

## ---- echo=FALSE---------------------------------------------------------
library(trajcomp)
alpha  <- c(0, 9,0 ,-7,-2,-3,6, -2, 1,0)

plot(alpha, pch=1, col="orange", ylim = c(-7,22),
  main="Original Curve",
  xlab="Index",
  ylab="Curvature (Degrees)")

legend(1,25, c( "curve"), col = c("orange"), lty = c( 1), pch = c(1), bty="n")
lines(alpha, col="orange")

bars <- persistence_test_bars(alpha)
bars_min <- bars[c(TRUE, FALSE)]
bars_max <- bars[c(FALSE, TRUE)]

# curve and bar plot
plot(alpha, pch=1, col="orange", ylim = c(-7,22),
main="Curve with bars",
xlab="Index",
ylab="Curvature (Degrees)")

legend(5,25, c("bars", "curve"), col = c("blue", "orange"), lty = c(1, 1), pch = c(-1,1), bty="n")

legend(1,25, c("min", "max"), col = c("green", "red"), lty = c(-1, -1), pch = c(1,1), bty="n")
lines(alpha, col="orange")
points(bars_min+1, alpha[bars_min+1], col="green", pch=1)
points(bars_max+1, alpha[bars_max+1], col="red", pch=1)

xLow <- bars_min+1
yLow <- alpha[bars_min+1]
xHigh <- bars_max+1
yHigh <- alpha[bars_max+1]
arrows(xHigh,yHigh,xLow,yLow,col="blue",angle=90,length=0.1,code=3)


## ---- echo=FALSE---------------------------------------------------------
library(trajcomp)
data(prague)

#get trajectory
prague$tid = getTrajectoryIDs(prague); # Add ID column
# and split on it
psplit = split (prague, f = prague$tid);
traj <- psplit[[1]];

#trajectory plot
plot(traj$x, traj$y, col="black", pch=21,
  main="Original Trajectory",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x, traj$y, col="orange")

pruned <- persistence_pruned(as.matrix(traj), 0)
#pruned trajectory plot
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 0",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="green")

pruned <- persistence_pruned(as.matrix(traj), 2)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 2",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="blue")

pruned <- persistence_pruned(as.matrix(traj), 4)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 4",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="red")

pruned <- persistence_pruned(as.matrix(traj), 8)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 8",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="orange")


pruned <- persistence_pruned(as.matrix(traj), 16)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 16",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="purple")


## ---- echo=FALSE---------------------------------------------------------
library(trajcomp)
data(prague)

#get trajectory
prague$tid = getTrajectoryIDs(prague); # Add ID column
# and split on it
psplit = split (prague, f = prague$tid);
traj <- psplit[[1]];


#trajectory plot
plot(traj$x, traj$y, col="black", pch=21,
  main="original trajectory",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x, traj$y, col="orange")


pruned <- persistence_multires(as.matrix(traj), 2, 1)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 2, levels = 1",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="green")

pruned <- persistence_multires(as.matrix(traj), 2, 2)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 2, levels = 2",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="blue")

pruned <- persistence_multires(as.matrix(traj), 2, 3)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 2, levels = 3",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="red")

pruned <- persistence_multires(as.matrix(traj), 2, 4)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 2, levels = 4",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="orange")

pruned <- persistence_multires(as.matrix(traj), 2, 5)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 2, levels = 5",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="purple")


## ---- echo=FALSE---------------------------------------------------------
library(trajcomp)
data(prague)

#get trajectory
prague$tid = getTrajectoryIDs(prague); # Add ID column
# and split on it
psplit = split (prague, f = prague$tid);
traj <- psplit[[1]];


#trajectory plot
plot(traj$x, traj$y, col="black", pch=21,
  main="original trajectory",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x, traj$y, col="orange")


pruned <- persistence_multires(as.matrix(traj), 4, 1)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 4, levels = 1",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="green")

pruned <- persistence_multires(as.matrix(traj), 4, 2)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 4, levels = 2",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="blue")

pruned <- persistence_multires(as.matrix(traj), 4, 3)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 4, levels = 3",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="red")

pruned <- persistence_multires(as.matrix(traj), 4, 4)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 4, levels = 4",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="orange")

pruned <- persistence_multires(as.matrix(traj), 4, 5)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 4, levels = 5",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="purple")


## ---- echo=FALSE---------------------------------------------------------
library(trajcomp)
data(prague)

#get trajectory
prague$tid = getTrajectoryIDs(prague); # Add ID column
# and split on it
psplit = split (prague, f = prague$tid);
traj <- psplit[[1]];


#trajectory plot
plot(traj$x, traj$y, col="black", pch=21,
  main="original trajectory",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x, traj$y, col="orange")


pruned <- persistence_multires(as.matrix(traj), 8, 1)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 8, levels = 1",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="green")

pruned <- persistence_multires(as.matrix(traj), 8, 2)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 8, levels = 2",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="blue")

pruned <- persistence_multires(as.matrix(traj), 8, 3)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 8, levels = 3",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="red")

pruned <- persistence_multires(as.matrix(traj), 8, 4)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 8, levels = 4",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="orange")

pruned <- persistence_multires(as.matrix(traj), 8, 5)
plot(traj$x[pruned+1], traj$y[pruned+1], col="black", pch=21,
  main="beta = 8, levels = 5",
  xlab="x-axis",
  ylab="y-axis")
lines(traj$x[pruned+1], traj$y[pruned+1], col="purple")


