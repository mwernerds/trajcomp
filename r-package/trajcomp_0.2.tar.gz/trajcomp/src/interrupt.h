#ifndef INTERRUPT_H_INC
#define INTERRUPT_H_INC

bool checkInterrupt();

#endif
